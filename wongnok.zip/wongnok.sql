-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 16, 2024 at 06:16 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wongnok`
--

-- --------------------------------------------------------

--
-- Table structure for table `hislike`
--

CREATE TABLE `hislike` (
  `likeid` int(10) NOT NULL,
  `userlike` int(3) NOT NULL,
  `itemlike` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hislike`
--

INSERT INTO `hislike` (`likeid`, `userlike`, `itemlike`) VALUES
(14, 1, 14),
(15, 1, 3),
(16, 2, 14),
(17, 2, 2),
(18, 2, 1),
(19, 5, 3),
(20, 5, 1),
(21, 5, 2),
(22, 5, 4),
(23, 3, 4),
(24, 3, 2),
(25, 3, 1),
(28, 1, 4),
(29, 4, 2),
(30, 1, 17);

-- --------------------------------------------------------

--
-- Table structure for table `hisview`
--

CREATE TABLE `hisview` (
  `hid` int(10) NOT NULL,
  `huser` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rid` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hisview`
--

INSERT INTO `hisview` (`hid`, `huser`, `rid`) VALUES
(1, '661d34b00ad29', 1),
(2, '661d34b00ad29', 2),
(3, '661d34b00ad29', 3),
(4, '661d34b00ad29', 4),
(5, '661d3a7263ec2', 1),
(6, '661d3dcf636c4', 1),
(7, '661d3dcf636c4', 2),
(8, '661d4a554b4ed', 3),
(10, '661d4a554b4ed', 2),
(12, '661d4a554b4ed', 4),
(13, '661d4a554b4ed', 1),
(16, '661d3a7263ec2', 2),
(17, '661d3a7263ec2', 3),
(18, '661d73c127c37', 4),
(19, '661d740e9b75e', 4),
(20, '661d752aee6b6', 4),
(23, '661d752aee6b6', 3),
(26, '661d77a6d915b', 1),
(27, '661d77a6d915b', 2),
(29, '661d77a6d915b', 3),
(31, '661d77a6d915b', 4),
(34, '661d752aee6b6', 1),
(35, '661d752aee6b6', 2),
(36, '661d3dcf636c4', 14),
(37, '661d4a554b4ed', 14),
(38, '661d3dcf636c4', 3),
(39, '661d3dcf636c4', 4),
(42, '661e8f42107ec', 4),
(43, '661e8f42107ec', 3),
(44, '661e8f42107ec', 14),
(45, '661e8f42107ec', 2),
(46, '661d4a554b4ed', 17),
(47, '661e8f42107ec', 17),
(48, '661d77a6d915b', 14),
(49, '661d77a6d915b', 17),
(50, '661e9e9b87c98', 4),
(51, '661e9e9b87c98', 14),
(52, '661e9e9b87c98', 3),
(53, '661e9e9b87c98', 17),
(54, '661e9e9b87c98', 2),
(55, '661e9e9b87c98', 1);

-- --------------------------------------------------------

--
-- Table structure for table `recipes`
--

CREATE TABLE `recipes` (
  `rid` int(3) NOT NULL,
  `rname` varchar(40) NOT NULL,
  `ringe` text NOT NULL,
  `rdetail` text NOT NULL,
  `rpic` varchar(20) NOT NULL,
  `rview` int(10) NOT NULL,
  `id` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `recipes`
--

INSERT INTO `recipes` (`rid`, `rname`, `ringe`, `rdetail`, `rpic`, `rview`, `id`) VALUES
(1, 'ผัดกระเพรา', '1.หมูชิ้นหรือหมูสับ 2.เครื่องปรุง 3.ใบกระเพราะ 4.อื่นๆ', 'ใส่น้ำมันนิดนึง เอาหมูลงผัดๆให้สุก ใส่อื่นๆตาม ผัดๆ แล้วใส่เครื่องปรุง ผัดๆ แล้วใส่กระเพรา คลุกๆให้หอม ถ้าชอบฉ่ำๆเติมน้ำนิดหน่อยแล้วคลุกๆ แล้วตักใส่จาน', '661798b255967.jpg', 7, 1),
(2, 'หมูกระเทียม', '1.หมู 2.เครื่องปรุง 3.กระเทียม', 'ปอกกระเทียม หันให้ละเอียด ใส่น้ำมัน แล้วใช้ไฟเบา ใส่กระเทียม แล้วรีบใส่หมูลงไปผัด ผัดๆให้สุก แล้วใส่เครื่องปรุง คลุกๆซักพัก ตักใส่จาน', '6617a05deba05.jpg', 8, 1),
(3, 'ผัดพริกแกงหมูสามชั้น', '1.พริกแกง 2.หมูสามชั้น 3.เครื่องปรุง 4. ถั่วฝักยาว', 'หั่นถั่วฝักยาวเป็นท่อนๆพอดีคำ ตั้งกระทะใส่น้ำมันนิดนึง แล้วใส่พริกแกงลงไปผัด ใส่หมูลงตามลงไปผัดให้สุก ให้เครื่องปรุง น้ำเปล่านิดหน่อย แล้วใส่ถั่วลงไปผัด คลุกๆซักพัก ตักใส่จาน', '6617a1b816ad7.jpg', 8, 2),
(4, 'ข้าวไข่เจียว', '1.ข้าวเปล่า 2.ไข่เจียว 3.เครื่องปรุง', 'ตักข้าวใส่จาน ตอกไข่ใส่ถ้วย ใส่เครื่องปรุงนิดหน่อย ตีๆๆ ให้ขึ้นฟอง แล้วตั้งกระทะ ใส่น้ำมันหน่อยนึง ตั้งไฟแรง ลงไข่ลงไป พลิกๆ ตั้งใส่จาน', '6617a2c1aa407.jpg', 9, 2),
(14, 'ปลาช่อนลุยสวน', 'ปลาช่อนบั้งและควักไส้ 700 กรัม\r\nมะม่วงเปรี้ยว ½ ลูก\r\nถั่วลิสง ½ ถ้วย\r\nใบสะระแหน่ ½ ถ้วย\r\nน้ำมะนาว 3 ช้อนโต๊ะ\r\nน้ำปลา 2 ช้อนโต๊ะ\r\nน้ำตาลทราย 2 ช้อนโต๊ะ\r\nน้ำพริกเผา 2 ช้อนโต๊ะ\r\nพริกแห้งทอด 9 เม็ด\r\nหอมแดงซอย 3 หัว\r\nผักชีฝรั่งซอย 1 ต้น\r\nพริกขี้หนูซอย 15 เม็ด\r\nตะไคร้ซอย 1 ต้น\r\nใบมะกรูดซอย 5 ใบ\r\nขิงแก่หั่นเต๋า ½ ถ้วย\r\nมะนาวหั่นเต๋า ½ ถ้วย ', 'STEP 1 : ทอดปลาช่อน\r\nนำปลาช่อนล้างทำความสะอาด ทาเกลือเล็กน้อย แล้วพักไว้\r\nตั้งกระทะโดยใช้ไฟแรง ใส่น้ำมันลงให้ท่วม รอจนน้ำมันเดือดแล้วหรี่ไฟกลาง นำปลาใส่ลงไปทอด ดูจนปลาสุกเหลืองกรอบทั้งตัว นำขึ้นพักให้สะเด็ดนำ้มัน\r\nSTEP 2 : ทำน้ำยำลุยสวน\r\nนำน้ำพริกเผา น้ำปลา น้ำตาลทราย และน้ำมะนาว มาคลุกให้เข้ากัน จากนั้นใส่พริกขี้หนูซอย ขิงแก่หั่นเต๋า มะนาวหั่นเต๋า หอมแดงซอย ตะไคร้ซอย ใบมะกรูดซอย ผักชีฝรั่งซอย ใบสะระแหน่ ถั่วลิสง และมะม่วงลงไปคลุกเคล้าให้เข้ากันอีกครั้ง  \r\nSTEP 3 : ราดน้ำยำ + จัดเสิร์ฟ\r\nนำผักกาดหอมรองจาน นำปลาช่อนที่ทอดแล้วมาวางลง ตามด้วยมะม่วงซอย เสร็จแล้วนำส่วนผสมที่คลุกเคล้าให้เข้ากันดีแล้ว นำไปราดลงบนตัวปลาช่อนที่ทอดเตรียมไว้\r\nเมื่อได้ “ปลาช่อนลุยสวน” แล้ว ตกแต่งด้วยพริกแห้ง ใบสะระแหน่ \r\n', '661e0ab2e4223.jpeg', 5, 5),
(17, 'ผัดผักรวมมิตรกุ้ง', '1.บรอกโคลี (หั่นชิ้น)\r\n\r\n2.ดอกกะหล่ำ (หั่นชิ้น)\r\n\r\n3.แครอต (หั่นตามชอบ)\r\n\r\n4.ดอกกะหล่ำ (หั่นชิ้น)\r\n\r\n5.กระเทียมสับ\r\n\r\n6.กุ้งสด (ปอกเปลือก, เอาหัวออก, ผ่าหลัง, ดึงเส้นดำออก)\r\n\r\n7.น้ำเปล่า (เล็กน้อย)\r\n\r\n8.น้ำตาลทราย\r\n\r\n9.ซีอิ๊วขาว\r\n\r\n10.ซอสหอยนางรม', '1.ตั้งหม้อใส่น้ำลงไป ตั้งไฟพอเดือด ใส่ผักต่าง ๆ ลงไปลวกพอแค่ผักเปลี่ยนสี ตักผักลวกขึ้นแช่ในน้ำเย็นจัดเพื่อเป็นการรักษาสารอาหารที่อยู่ในผักและทำให้ผักมีสีสวยน่ากินยิ่งขึ้น\r\n\r\n2.ตั้งกระทะใส่น้ำมันลงไป ใส่กระเทียมลงไปเจียวจนหอม ใส่กุ้งลงไปผัดพอสุก ใส่ผักรวมลวกลงไป เติมน้ำเปล่าเล็กน้อย ปรุงรสตามชอบ ผัดทุกอย่างจนเข้ากัน ตักเสิร์ฟ', '661e9957b6d98.jpg', 4, 4);

-- --------------------------------------------------------

--
-- Table structure for table `verilog`
--

CREATE TABLE `verilog` (
  `id` int(2) NOT NULL,
  `user` varchar(15) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `verilog`
--

INSERT INTO `verilog` (`id`, `user`, `email`, `pass`) VALUES
(1, 'admin', 'admin@email.com', 'admin'),
(2, 'test1', 'test1@mail.com', 'test1'),
(3, 'test2', 'test2@mail.com', 'test2'),
(4, 'test3', 'test3@mail.com', 'test3'),
(5, 'Minkie', 'e_ming_zz@hotmail.com', '11052555');

-- --------------------------------------------------------

--
-- Table structure for table `viewlike`
--

CREATE TABLE `viewlike` (
  `viewid` int(10) NOT NULL,
  `id` int(2) NOT NULL,
  `rid` int(3) NOT NULL,
  `gotlike` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `viewlike`
--

INSERT INTO `viewlike` (`viewid`, `id`, `rid`, `gotlike`) VALUES
(1, 1, 1, 3),
(2, 1, 2, 4),
(3, 2, 3, 2),
(4, 2, 4, 3),
(13, 5, 14, 2),
(16, 4, 17, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hislike`
--
ALTER TABLE `hislike`
  ADD PRIMARY KEY (`likeid`);

--
-- Indexes for table `hisview`
--
ALTER TABLE `hisview`
  ADD PRIMARY KEY (`hid`),
  ADD KEY `hisviewrid` (`rid`);

--
-- Indexes for table `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `ownerof` (`id`);

--
-- Indexes for table `verilog`
--
ALTER TABLE `verilog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `viewlike`
--
ALTER TABLE `viewlike`
  ADD PRIMARY KEY (`viewid`),
  ADD KEY `userid` (`id`),
  ADD KEY `itemid` (`rid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hislike`
--
ALTER TABLE `hislike`
  MODIFY `likeid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `hisview`
--
ALTER TABLE `hisview`
  MODIFY `hid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT for table `recipes`
--
ALTER TABLE `recipes`
  MODIFY `rid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `verilog`
--
ALTER TABLE `verilog`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `viewlike`
--
ALTER TABLE `viewlike`
  MODIFY `viewid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hisview`
--
ALTER TABLE `hisview`
  ADD CONSTRAINT `hisviewrid` FOREIGN KEY (`rid`) REFERENCES `recipes` (`rid`);

--
-- Constraints for table `recipes`
--
ALTER TABLE `recipes`
  ADD CONSTRAINT `ownerof` FOREIGN KEY (`id`) REFERENCES `verilog` (`id`);

--
-- Constraints for table `viewlike`
--
ALTER TABLE `viewlike`
  ADD CONSTRAINT `itemid` FOREIGN KEY (`rid`) REFERENCES `recipes` (`rid`),
  ADD CONSTRAINT `userid` FOREIGN KEY (`id`) REFERENCES `verilog` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
