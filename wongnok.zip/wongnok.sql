-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 15, 2024 at 07:04 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wongnok`
--

-- --------------------------------------------------------

--
-- Table structure for table `hisview`
--

CREATE TABLE `hisview` (
  `hid` int(10) NOT NULL,
  `huser` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rid` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hisview`
--

INSERT INTO `hisview` (`hid`, `huser`, `rid`) VALUES
(1, '661d34b00ad29', 1),
(2, '661d34b00ad29', 2),
(3, '661d34b00ad29', 3),
(4, '661d34b00ad29', 4),
(5, '661d3a7263ec2', 1),
(6, '661d3dcf636c4', 1),
(7, '661d3dcf636c4', 2),
(8, '661d4a554b4ed', 3),
(10, '661d4a554b4ed', 2),
(12, '661d4a554b4ed', 4),
(13, '661d4a554b4ed', 1);

-- --------------------------------------------------------

--
-- Table structure for table `recipes`
--

CREATE TABLE `recipes` (
  `rid` int(3) NOT NULL,
  `rname` varchar(40) NOT NULL,
  `ringe` text NOT NULL,
  `rdetail` text NOT NULL,
  `rpic` varchar(20) NOT NULL,
  `rview` int(10) NOT NULL,
  `id` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `recipes`
--

INSERT INTO `recipes` (`rid`, `rname`, `ringe`, `rdetail`, `rpic`, `rview`, `id`) VALUES
(1, 'ผัดกระเพรา', '1.หมูชิ้นหรือหมูสับ 2.เครื่องปรุง 3.ใบกระเพราะ 4.อื่นๆ', 'ใส่น้ำมันนิดนึง เอาหมูลงผัดๆให้สุก ใส่อื่นๆตาม ผัดๆ แล้วใส่เครื่องปรุง ผัดๆ แล้วใส่กระเพรา คลุกๆให้หอม ถ้าชอบฉ่ำๆเติมน้ำนิดหน่อยแล้วคลุกๆ แล้วตักใส่จาน', '661798b255967.jpg', 4, 1),
(2, 'หมูกระเทียม', '1.หมู 2.เครื่องปรุง 3.กระเทียม', 'ปอกกระเทียม หันให้ละเอียด ใส่น้ำมัน แล้วใช้ไฟเบา ใส่กระเทียม แล้วรีบใส่หมูลงไปผัด ผัดๆให้สุก แล้วใส่เครื่องปรุง คลุกๆซักพัก ตักใส่จาน', '6617a05deba05.jpg', 3, 1),
(3, 'ผัดพริกแกงหมูสามชั้น', '1.พริกแกง 2.หมูสามชั้น 3.เครื่องปรุง 4. ถั่วฝักยาว', 'หั่นถั่วฝักยาวเป็นท่อนๆพอดีคำ ตั้งกระทะใส่น้ำมันนิดนึง แล้วใส่พริกแกงลงไปผัด ใส่หมูลงตามลงไปผัดให้สุก ให้เครื่องปรุง น้ำเปล่านิดหน่อย แล้วใส่ถั่วลงไปผัด คลุกๆซักพัก ตักใส่จาน', '6617a1b816ad7.jpg', 2, 2),
(4, 'ข้าวไข่เจียว', '1.ข้าวเปล่า 2.ไข่เจียว 3.เครื่องปรุง', 'ตักข้าวใส่จาน ตอกไข่ใส่ถ้วย ใส่เครื่องปรุงนิดหน่อย ตีๆๆ ให้ขึ้นฟอง แล้วตั้งกระทะ ใส่น้ำมันหน่อยนึง ตั้งไฟแรง ลงไข่ลงไป พลิกๆ ตั้งใส่จาน', '6617a2c1aa407.jpg', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `verilog`
--

CREATE TABLE `verilog` (
  `id` int(2) NOT NULL,
  `user` varchar(15) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `verilog`
--

INSERT INTO `verilog` (`id`, `user`, `email`, `pass`) VALUES
(1, 'admin', 'admin@email.com', 'admin'),
(2, 'test1', 'test1@mail.com', 'test1');

-- --------------------------------------------------------

--
-- Table structure for table `viewlike`
--

CREATE TABLE `viewlike` (
  `viewid` int(10) NOT NULL,
  `id` int(2) NOT NULL,
  `rid` int(3) NOT NULL,
  `gotlike` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `viewlike`
--

INSERT INTO `viewlike` (`viewid`, `id`, `rid`, `gotlike`) VALUES
(1, 1, 1, 0),
(2, 1, 2, 0),
(3, 2, 3, 0),
(4, 2, 4, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hisview`
--
ALTER TABLE `hisview`
  ADD PRIMARY KEY (`hid`),
  ADD KEY `hisviewrid` (`rid`);

--
-- Indexes for table `recipes`
--
ALTER TABLE `recipes`
  ADD PRIMARY KEY (`rid`),
  ADD KEY `ownerof` (`id`);

--
-- Indexes for table `verilog`
--
ALTER TABLE `verilog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `viewlike`
--
ALTER TABLE `viewlike`
  ADD PRIMARY KEY (`viewid`),
  ADD KEY `userid` (`id`),
  ADD KEY `itemid` (`rid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hisview`
--
ALTER TABLE `hisview`
  MODIFY `hid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `recipes`
--
ALTER TABLE `recipes`
  MODIFY `rid` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `verilog`
--
ALTER TABLE `verilog`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `viewlike`
--
ALTER TABLE `viewlike`
  MODIFY `viewid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `hisview`
--
ALTER TABLE `hisview`
  ADD CONSTRAINT `hisviewrid` FOREIGN KEY (`rid`) REFERENCES `recipes` (`rid`);

--
-- Constraints for table `recipes`
--
ALTER TABLE `recipes`
  ADD CONSTRAINT `ownerof` FOREIGN KEY (`id`) REFERENCES `verilog` (`id`);

--
-- Constraints for table `viewlike`
--
ALTER TABLE `viewlike`
  ADD CONSTRAINT `itemid` FOREIGN KEY (`rid`) REFERENCES `recipes` (`rid`),
  ADD CONSTRAINT `userid` FOREIGN KEY (`id`) REFERENCES `verilog` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
